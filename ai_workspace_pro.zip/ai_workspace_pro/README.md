# AI Workspace Pro — All-in-One AI Assistant

A Streamlit workspace bundling twelve AI tools behind one dashboard, built to
match the reference design: dark violet UI, feature-card home screen, live
activity rail and quick stats.

## Features

| Tool | What it does |
|---|---|
| AI Chat | Multi-turn assistant with preset prompts and saved history |
| Code Assistant | Fix, explain, optimize, generate, test and convert code across 11 languages |
| Data Analysis | CSV/Excel upload, profiling, cleaning, six Plotly chart types, AI insights, CSV/Excel export |
| Resume Analyzer | Rule-based ATS score, keyword gap analysis against a job description, AI rewrite suggestions |
| Roadmap Generator | Phased career roadmap tuned to your level, weekly hours and target timeline |
| PDF Chat | Chunking + TF-IDF vectors + FAISS retrieval, answers grounded in your document |
| OCR | Tesseract image-to-text with preprocessing and AI cleanup |
| Translator | 12 languages, tone control, Gemini with a deep-translator fallback |
| Voice AI | Speech-to-text (mic or file) and text-to-speech via gTTS |
| Notes Generator | Structured study notes with flashcards and quizzes, Markdown export |
| Study Planner | AI schedule builder plus a persistent SQLite task tracker with progress charts |
| Settings | Dark mode, font size, language, API key, stats and data controls |

## Stack

Python · Streamlit · Google Gemini API · Pandas · Plotly · scikit-learn · FAISS · SQLite

## Setup

```bash
git clone <your-repo> && cd ai_workspace_pro
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # then paste your Gemini key
streamlit run app.py
```

OCR also needs the Tesseract binary:

```bash
sudo apt install tesseract-ocr          # Ubuntu/Debian
brew install tesseract                  # macOS
# Windows: https://github.com/UB-Mannheim/tesseract/wiki
```

Language packs for non-English OCR: `sudo apt install tesseract-ocr-urd tesseract-ocr-ara`

## Without an API key

Every screen still loads. Rule-based paths (ATS scoring, data profiling, charts,
OCR, translation fallback, TTS, the task tracker) work fully offline; model-backed
answers return a clear "no API key configured" notice instead of failing.

## Layout

```
ai_workspace_pro/
├── app.py               # shell: sidebar nav, dashboard, routing
├── config.py            # design tokens, feature registry, constants
├── core/
│   ├── ai.py            # Gemini wrapper + offline fallback
│   ├── db.py            # SQLite: chats, stats, settings, tasks
│   └── theme.py         # CSS injection matching the design
├── modules/             # one file per tool, each exposing render()
├── .streamlit/config.toml
└── requirements.txt
```

## Adding a tool

1. Create `modules/yourtool.py` with a `render()` function.
2. Add a `(key, label, icon, blurb)` row to `FEATURES` in `config.py`.
3. Register it in `ROUTES` in `app.py`. It appears in the sidebar and on the home grid automatically.
