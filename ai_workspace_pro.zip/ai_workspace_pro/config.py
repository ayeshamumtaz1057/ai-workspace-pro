"""Central configuration for AI Workspace Pro."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = DATA_DIR / "workspace.db"
UPLOAD_DIR = DATA_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

APP_NAME = "AI Workspace Pro"
APP_TAGLINE = "All-in-One AI Assistant"

# ---- Model / API ----------------------------------------------------------
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

# ---- Design tokens (mirrors the mockup) -----------------------------------
THEME = {
    "bg":        "#05060f",
    "surface":   "#0d1020",
    "surface_2": "#141830",
    "border":    "#232a4d",
    "text":      "#e8ebff",
    "muted":     "#8b93bd",
    "primary":   "#8b5cf6",
    "accent":    "#22d3ee",
    "pink":      "#e879f9",
    "green":     "#34d399",
    "amber":     "#fbbf24",
    "red":       "#f87171",
}

# ---- Feature registry -----------------------------------------------------
# (key, label, icon, blurb) — drives the sidebar, home cards and left rail.
FEATURES = [
    ("home",      "Home",             "🏠", "Your workspace dashboard"),
    ("chat",      "AI Chat",          "💬", "Chat with AI and get answers to anything"),
    ("code",      "Code Assistant",   "⌨️", "Write, fix, explain, and optimize your code"),
    ("data",      "Data Analysis",    "📊", "Upload data, analyze, and get AI insights"),
    ("resume",    "Resume Analyzer",  "📄", "Analyze your resume and improve it"),
    ("roadmap",   "Roadmap Generator","🗺️", "Get personalized career roadmaps"),
    ("pdf",       "PDF Chat",         "📕", "Chat with your PDF documents"),
    ("ocr",       "OCR",              "🖼️", "Extract text from images using OCR"),
    ("translate", "Translator",       "🌐", "Translate text in multiple languages"),
    ("voice",     "Voice AI",         "🎙️", "Convert speech to text and text to speech"),
    ("notes",     "Notes Generator",  "📝", "Generate study notes on any topic"),
    ("planner",   "Study Planner",    "🗓️", "Plan your study schedule and track progress"),
    ("settings",  "Settings",         "⚙️", "Appearance, language and data controls"),
]

HOME_CARDS = [k for k, *_ in FEATURES if k not in ("home", "settings")]

VALUE_PROPS = [
    ("💡", "AI Powered",    "Smart responses using advanced AI models"),
    ("🔒", "Secure",        "Your data is safe and 100% private"),
    ("⚡", "Fast",          "Lightning fast performance"),
    ("👥", "User Friendly", "Clean and modern interface"),
    ("🧩", "All-in-One",    "All tools in one powerful app"),
    ("📤", "Export Reports","Export results as PDF, Excel, CSV"),
]

TECH_STACK = ["Python", "Streamlit", "Google Gemini API", "Pandas", "Plotly",
              "scikit-learn", "LangChain", "FAISS", "SQLite"]

LANGUAGES = ["English", "Urdu", "Arabic", "Hindi", "Spanish", "French",
             "German", "Chinese", "Japanese", "Turkish", "Russian", "Portuguese"]
