"""Injects the dark violet workspace styling seen in the design."""
import streamlit as st
from config import THEME as T


def inject_css(font_size: str = "Medium", dark: bool = True) -> None:
    scale = {"Small": "14px", "Medium": "15px", "Large": "17px"}.get(font_size, "15px")
    light_override = "" if dark else f"""
      .stApp {{ background:#f4f5fb !important; color:#141830 !important; }}
      .aw-card, .aw-panel {{ background:#ffffff !important; border-color:#dde0f0 !important; }}
      .aw-card h4, .aw-panel h3 {{ color:#141830 !important; }}
      .aw-card p, .aw-muted {{ color:#5b6288 !important; }}
    """

    st.markdown(f"""
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;600&display=swap');

      html, body, [class*="css"] {{ font-family:'Inter',sans-serif; font-size:{scale}; }}
      .stApp {{ background:
          radial-gradient(1100px 500px at 78% -8%, rgba(139,92,246,.20), transparent 60%),
          radial-gradient(800px 420px at 8% 108%, rgba(34,211,238,.13), transparent 62%),
          {T['bg']};
          color:{T['text']}; }}
      section[data-testid="stSidebar"] {{
          background:{T['surface']}; border-right:1px solid {T['border']}; }}
      #MainMenu, footer {{ visibility:hidden; }}

      /* ---- Wordmark ---- */
      .aw-wordmark {{ font-family:'Space Grotesk',sans-serif; font-weight:700;
          font-size:clamp(28px,4.6vw,54px); letter-spacing:.06em; text-align:center;
          background:linear-gradient(90deg,{T['pink']},{T['primary']} 45%,{T['accent']});
          -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin:.2rem 0 0; }}
      .aw-sub {{ text-align:center; color:{T['muted']}; letter-spacing:.35em;
          font-size:.72rem; text-transform:uppercase; margin-bottom:1.4rem; }}

      /* ---- Cards & panels ---- */
      .aw-card {{ background:linear-gradient(180deg,{T['surface_2']},{T['surface']});
          border:1px solid {T['border']}; border-radius:16px; padding:16px 18px;
          height:100%; transition:.18s ease; }}
      .aw-card:hover {{ transform:translateY(-3px); border-color:{T['primary']};
          box-shadow:0 10px 30px rgba(139,92,246,.22); }}
      .aw-card .aw-ico {{ font-size:1.45rem; }}
      .aw-card h4 {{ margin:.45rem 0 .2rem; font-size:.98rem; color:{T['text']}; }}
      .aw-card p {{ margin:0; font-size:.8rem; color:{T['muted']}; line-height:1.45; }}

      .aw-panel {{ background:{T['surface']}; border:1px solid {T['border']};
          border-radius:16px; padding:14px 16px; }}
      .aw-panel h3 {{ font-size:.9rem; margin:0 0 .7rem; color:{T['text']};
          letter-spacing:.08em; text-transform:uppercase; }}

      .aw-row {{ display:flex; justify-content:space-between; align-items:center;
          padding:7px 0; border-bottom:1px dashed {T['border']}; font-size:.84rem; }}
      .aw-row:last-child {{ border-bottom:none; }}
      .aw-muted {{ color:{T['muted']}; font-size:.78rem; }}
      .aw-pill {{ display:inline-block; padding:3px 10px; border-radius:999px;
          font-size:.7rem; border:1px solid {T['border']}; color:{T['muted']};
          margin:0 6px 6px 0; background:{T['surface_2']}; }}
      .aw-strip {{ background:linear-gradient(90deg,{T['surface']},{T['surface_2']});
          border:1px solid {T['border']}; border-radius:14px; padding:12px 14px; }}
      .aw-strip b {{ display:block; font-size:.85rem; }}
      .aw-strip span {{ font-size:.74rem; color:{T['muted']}; }}

      /* ---- Controls ---- */
      .stButton>button {{ border-radius:10px; border:1px solid {T['border']};
          background:{T['surface_2']}; color:{T['text']}; font-weight:600; }}
      .stButton>button:hover {{ border-color:{T['primary']}; color:#fff;
          background:linear-gradient(90deg,{T['primary']},{T['accent']}); }}
      .stTextInput input, .stTextArea textarea, .stSelectbox div[data-baseweb="select"] > div {{
          background:{T['surface_2']} !important; color:{T['text']} !important;
          border-color:{T['border']} !important; border-radius:10px !important; }}
      .stTabs [data-baseweb="tab-list"] {{ gap:6px; }}
      .stTabs [data-baseweb="tab"] {{ background:{T['surface_2']}; border-radius:10px 10px 0 0;
          padding:6px 14px; border:1px solid {T['border']}; border-bottom:none; }}
      code, pre, .stCode {{ font-family:'JetBrains Mono',monospace !important; }}
      {light_override}
    </style>
    """, unsafe_allow_html=True)


def card(icon: str, title: str, body: str) -> str:
    return (f"<div class='aw-card'><div class='aw-ico'>{icon}</div>"
            f"<h4>{title}</h4><p>{body}</p></div>")


def header(title: str, subtitle: str = "") -> None:
    st.markdown(f"<div class='aw-wordmark'>{title}</div>", unsafe_allow_html=True)
    if subtitle:
        st.markdown(f"<div class='aw-sub'>{subtitle}</div>", unsafe_allow_html=True)
