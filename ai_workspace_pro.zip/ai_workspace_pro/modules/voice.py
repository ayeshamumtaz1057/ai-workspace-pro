"""Voice AI — speech to text and text to speech."""
import io
import streamlit as st
from core import ai, db
from config import LANGUAGES

TTS_CODES = {"English": "en", "Urdu": "ur", "Arabic": "ar", "Hindi": "hi",
             "Spanish": "es", "French": "fr", "German": "de", "Chinese": "zh-CN",
             "Japanese": "ja", "Turkish": "tr", "Russian": "ru", "Portuguese": "pt"}


def _speech_to_text(audio_bytes: bytes) -> str:
    import speech_recognition as sr
    r = sr.Recognizer()
    with sr.AudioFile(io.BytesIO(audio_bytes)) as source:
        audio = r.record(source)
    return r.recognize_google(audio)


def render():
    st.subheader("🎙️ Voice AI")
    st.caption("Convert speech to text and text to speech.")

    stt, tts = st.tabs(["Speech to Text", "Text to Speech"])

    with stt:
        audio = st.audio_input("Record a message")
        upload = st.file_uploader("…or upload a WAV / AIFF file", type=["wav", "aiff", "flac"])
        source = audio or upload
        if source and st.button("Transcribe", type="primary"):
            try:
                with st.spinner("Transcribing…"):
                    text = _speech_to_text(source.getvalue() if hasattr(source, "getvalue")
                                           else source.read())
            except Exception as exc:
                st.error(f"Transcription failed: {exc}\n\n"
                         "WAV works best. Install `SpeechRecognition` and check your connection.")
            else:
                st.text_area("Transcript", text, height=160)
                st.session_state["voice_text"] = text
                db.log_message("Voice AI", text[:40], "user", text)

        if st.session_state.get("voice_text") and st.button("Ask AI about this transcript"):
            with st.spinner("Thinking…"):
                st.markdown(ai.ask(st.session_state["voice_text"],
                                   system="Summarise this transcript and list any action items."))

    with tts:
        text = st.text_area("Text to speak", "This is a sample text converted from speech.",
                            height=140)
        lang = st.selectbox("Voice language", LANGUAGES)
        slow = st.checkbox("Speak slowly")
        if st.button("Generate audio", type="primary") and text.strip():
            try:
                from gtts import gTTS
                buf = io.BytesIO()
                gTTS(text=text, lang=TTS_CODES.get(lang, "en"), slow=slow).write_to_fp(buf)
                st.audio(buf.getvalue(), format="audio/mp3")
                st.download_button("Download MP3", buf.getvalue(), "speech.mp3")
            except Exception as exc:
                st.error(f"Speech generation failed: {exc}\n\nInstall it with `pip install gTTS`.")
