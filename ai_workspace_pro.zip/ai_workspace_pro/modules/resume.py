"""Resume Analyzer — ATS score, keyword gaps, rewrite suggestions."""
import json
import re
import streamlit as st
from core import ai, db

SECTIONS = ["contact", "summary", "experience", "education", "skills", "projects"]
ACTION_VERBS = {"led", "built", "designed", "improved", "reduced", "launched",
                "automated", "delivered", "increased", "optimized", "managed"}


def extract_text(file) -> str:
    if file is None:
        return ""
    name = file.name.lower()
    if name.endswith(".pdf"):
        from pypdf import PdfReader
        return "\n".join((p.extract_text() or "") for p in PdfReader(file).pages)
    if name.endswith(".docx"):
        import docx
        return "\n".join(p.text for p in docx.Document(file).paragraphs)
    return file.read().decode("utf-8", errors="ignore")


def heuristic_score(text: str) -> tuple[int, list[str]]:
    """Rule-based ATS score so the tool works even without an API key."""
    t = text.lower()
    score, notes = 40, []
    found = [s for s in SECTIONS if s in t]
    score += len(found) * 5
    missing = [s for s in SECTIONS if s not in found]
    if missing:
        notes.append(f"Sections not detected: {', '.join(missing)}")
    if re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", text):
        score += 5
    else:
        notes.append("No email address found — ATS parsers need one in the header.")
    numbers = len(re.findall(r"\b\d+%|\b\d[\d,]{2,}\b", text))
    score += min(numbers, 5) * 2
    if numbers < 3:
        notes.append("Add quantified results (%, $, counts) to your bullets.")
    verbs = ACTION_VERBS & set(re.findall(r"[a-z]+", t))
    if len(verbs) < 4:
        notes.append("Start more bullets with strong action verbs.")
    words = len(text.split())
    if words < 200:
        notes.append("Resume looks short — aim for 400–800 words.")
    elif words > 1200:
        notes.append("Resume looks long — trim to two pages maximum.")
    return max(0, min(score, 100)), notes


def render():
    st.subheader("📄 Resume Analyzer")
    st.caption("Check ATS score, get feedback and improve your resume.")

    file = st.file_uploader("Upload resume (PDF, DOCX or TXT)", type=["pdf", "docx", "txt"])
    jd = st.text_area("Paste the job description (optional, improves matching)", height=120)

    if not file:
        st.info("Upload a resume to get an ATS score, keyword gaps and rewrite suggestions.")
        return

    text = extract_text(file)
    if not text.strip():
        st.error("No text could be extracted. If this is a scanned PDF, run it through OCR first.")
        return

    score, notes = heuristic_score(text)
    c1, c2 = st.columns([1, 2])
    with c1:
        st.metric("ATS score", f"{score}/100",
                  "Good match" if score >= 75 else "Needs work")
        st.progress(score / 100)
    with c2:
        st.write("**Quick checks**")
        for n in notes or ["No structural problems detected."]:
            st.write("• " + n)

    if jd.strip():
        rw = set(re.findall(r"[a-zA-Z][a-zA-Z+#.]{2,}", jd.lower()))
        have = set(re.findall(r"[a-zA-Z][a-zA-Z+#.]{2,}", text.lower()))
        common = {"the", "and", "for", "with", "you", "our", "will", "are", "have", "this"}
        gaps = sorted(rw - have - common)[:20]
        st.write("**Keywords in the job description that are missing from your resume**")
        st.write(", ".join(gaps) if gaps else "None — strong keyword coverage.")

    if st.button("Get detailed AI feedback", type="primary"):
        with st.spinner("Reviewing your resume…"):
            out = ai.ask(f"RESUME:\n{text[:12000]}\n\nJOB DESCRIPTION:\n{jd[:4000]}",
                         system=("You are a technical recruiter. Return: ATS score out of 100 "
                                 "with reasoning, missing skills, three rewritten bullet points "
                                 "using the XYZ formula, and a stronger professional summary."))
        st.markdown(out)
        st.download_button("Download feedback", out, "resume_feedback.md")
    db.bump("files_analyzed")
    db.log_message("Resume Analyzer", file.name, "user", "analyze")
