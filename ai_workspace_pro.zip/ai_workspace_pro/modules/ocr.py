"""OCR — image to text via Tesseract, with optional AI cleanup."""
import streamlit as st
from core import ai, db

LANG_CODES = {"English": "eng", "Urdu": "urd", "Arabic": "ara", "Hindi": "hin",
              "Spanish": "spa", "French": "fra", "German": "deu"}


def run_ocr(image, lang_code: str) -> str:
    import pytesseract
    return pytesseract.image_to_string(image, lang=lang_code)


def render():
    st.subheader("🖼️ OCR — Image to Text")
    st.caption("Extract text from images using advanced OCR.")

    file = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg", "bmp", "tiff", "webp"])
    c1, c2 = st.columns(2)
    lang = c1.selectbox("Document language", list(LANG_CODES))
    enhance = c2.checkbox("Preprocess (grayscale + sharpen)", value=True)

    if not file:
        st.info("Upload a photo, scan or screenshot to pull the text out of it.")
        return

    from PIL import Image, ImageOps, ImageFilter
    img = Image.open(file)
    if enhance:
        img = ImageOps.grayscale(img).filter(ImageFilter.SHARPEN)
        img = ImageOps.autocontrast(img)

    left, right = st.columns(2)
    left.image(img, caption=file.name, use_container_width=True)

    if right.button("Extract text", type="primary"):
        try:
            text = run_ocr(img, LANG_CODES[lang])
        except Exception as exc:
            right.error(f"Tesseract is not available: {exc}\n\n"
                        "Install it with `sudo apt install tesseract-ocr`.")
            return
        right.text_area("Extracted text", text, height=320)
        right.download_button("Download .txt", text, "extracted_text.txt")
        st.session_state["ocr_text"] = text
        db.bump("files_analyzed")
        db.log_message("OCR", file.name, "user", "extract")

    if st.session_state.get("ocr_text") and st.button("Clean up and summarize with AI"):
        with st.spinner("Tidying the text…"):
            out = ai.ask(st.session_state["ocr_text"][:8000],
                         system=("Fix OCR errors and formatting in this text, then add a "
                                 "three-sentence summary under a 'Summary' heading."))
        st.markdown(out)
