"""Translator — model-backed translation with a deep-translator fallback."""
import streamlit as st
from core import ai, db
from config import LANGUAGES

CODES = {"English": "en", "Urdu": "ur", "Arabic": "ar", "Hindi": "hi",
         "Spanish": "es", "French": "fr", "German": "de", "Chinese": "zh-CN",
         "Japanese": "ja", "Turkish": "tr", "Russian": "ru", "Portuguese": "pt"}


def _offline(text, src, dst):
    try:
        from deep_translator import GoogleTranslator
        return GoogleTranslator(source=CODES.get(src, "auto"),
                                target=CODES.get(dst, "en")).translate(text)
    except Exception:
        return None


def render():
    st.subheader("🌐 Translator")
    st.caption("Translate text into multiple languages instantly.")

    c1, c2 = st.columns(2)
    src = c1.selectbox("From", ["Auto-detect"] + LANGUAGES)
    dst = c2.selectbox("To", LANGUAGES, index=LANGUAGES.index("Urdu"))
    text = st.text_area("Text", "Hello, how are you?", height=140)
    tone = st.select_slider("Tone", ["Literal", "Natural", "Formal", "Casual"], "Natural")

    if st.button("Translate", type="primary") and text.strip():
        with st.spinner("Translating…"):
            if ai.is_ready():
                out = ai.ask(text,
                             system=f"Translate from {src} to {dst}. Tone: {tone}. "
                                    "Return only the translation.",
                             temperature=0.2)
            else:
                out = _offline(text, src, dst) or ai.ask(text)
        st.text_area("Translation", out, height=140)
        db.log_message("Translator", text[:40], "user", text)
