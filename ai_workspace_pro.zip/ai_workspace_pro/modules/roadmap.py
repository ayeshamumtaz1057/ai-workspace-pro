"""Roadmap Generator — personalised, phased career roadmaps."""
import streamlit as st
from core import ai, db

GOALS = ["AI Engineer", "Data Scientist", "Data Analyst", "ML Engineer",
         "Full-Stack Developer", "Backend Developer", "Frontend Developer",
         "DevOps Engineer", "Cybersecurity Analyst", "Mobile Developer", "Custom…"]

FALLBACK = {
    "AI Engineer": ["Python programming", "SQL & databases", "Data structures & algorithms",
                    "Machine learning", "Deep learning", "LLMs & NLP",
                    "Projects & portfolio", "Deploy & freelance"],
}


def render():
    st.subheader("🗺️ Roadmap Generator")
    st.caption("Get a personalized career roadmap with clear steps.")

    goal = st.selectbox("Select career goal", GOALS)
    if goal == "Custom…":
        goal = st.text_input("Describe your goal", "Prompt engineer")

    c1, c2, c3 = st.columns(3)
    level = c1.selectbox("Current level", ["Complete beginner", "Some basics", "Intermediate"])
    hours = c2.slider("Hours per week", 3, 40, 12)
    months = c3.slider("Target timeline (months)", 1, 24, 6)

    if st.button("Generate roadmap", type="primary"):
        with st.spinner("Mapping your path…"):
            out = ai.ask(
                f"Goal: {goal}\nLevel: {level}\nTime: {hours} h/week for {months} months",
                system=("Create a phased learning roadmap. For each phase give: name, duration, "
                        "skills to learn, 2 free resources, and one portfolio project. "
                        "End with a hiring-readiness checklist. Use markdown with headings."))
        st.markdown(out)
        st.download_button("Download roadmap", out, f"{goal.replace(' ', '_')}_roadmap.md")
        db.log_message("Roadmap Generator", goal, "user", goal)

    with st.expander("Standard AI Engineer track (offline reference)"):
        for i, step in enumerate(FALLBACK["AI Engineer"], 1):
            st.write(f"**{i:02d}** · {step}")
