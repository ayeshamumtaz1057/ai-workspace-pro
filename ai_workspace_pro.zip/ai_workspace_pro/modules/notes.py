"""Notes Generator — structured study notes on any topic."""
import streamlit as st
from core import ai, db

DEPTH = {"Quick revision": 400, "Standard notes": 900, "Deep dive": 1600}


def render():
    st.subheader("📝 Notes Generator")
    st.caption("Generate structured study notes on any topic.")

    topic = st.text_input("Topic", "Neural networks")
    c1, c2, c3 = st.columns(3)
    level = c1.selectbox("Level", ["Beginner", "Intermediate", "Advanced"])
    depth = c2.selectbox("Depth", list(DEPTH))
    extras = c3.multiselect("Include", ["Definitions", "Examples", "Diagrams (text)",
                                        "Formulas", "Flashcards", "Quiz"],
                            default=["Definitions", "Examples", "Flashcards"])

    if st.button("Generate notes", type="primary") and topic.strip():
        with st.spinner("Writing your notes…"):
            notes = ai.ask(
                f"Topic: {topic}\nLevel: {level}\nSections to include: {', '.join(extras)}",
                system=("Write well-structured markdown study notes with headings, "
                        f"bullet points and a summary. Aim for about {DEPTH[depth]} words."),
            )
        st.markdown(notes)
        st.download_button("Download as Markdown", notes,
                           file_name=f"{topic.replace(' ', '_')}_notes.md")
        db.log_message("Notes Generator", topic, "user", topic)
