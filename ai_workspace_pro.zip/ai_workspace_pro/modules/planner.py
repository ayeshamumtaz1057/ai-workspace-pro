"""Study Planner — AI-generated schedules plus a persistent task tracker."""
from datetime import date, timedelta
import pandas as pd
import plotly.express as px
import streamlit as st
from core import ai, db


def render():
    st.subheader("🗓️ Study Planner")
    st.caption("Plan your study schedule and track progress.")

    build, track = st.tabs(["Build a plan", "My tasks"])

    with build:
        c1, c2 = st.columns(2)
        subject = c1.text_input("Subject or exam", "Machine Learning")
        exam = c2.date_input("Target date", date.today() + timedelta(days=30))
        c3, c4 = st.columns(2)
        hours = c3.slider("Hours available per day", 1, 10, 3)
        style = c4.selectbox("Study style", ["Pomodoro", "Deep work blocks", "Spaced repetition"])
        topics = st.text_area("Topics to cover (one per line)",
                              "Linear regression\nDecision trees\nNeural networks\nModel evaluation")

        if st.button("Generate schedule", type="primary"):
            days = max(1, (exam - date.today()).days)
            with st.spinner("Building your schedule…"):
                plan = ai.ask(
                    f"Subject: {subject}\nDays available: {days}\nHours/day: {hours}\n"
                    f"Method: {style}\nTopics:\n{topics}",
                    system=("Produce a day-by-day study schedule as a markdown table with "
                            "columns Day, Date, Topic, Activities, Revision. End with three "
                            "exam-week tips."))
            st.markdown(plan)
            st.download_button("Download plan", plan, "study_plan.md")
            db.log_message("Study Planner", subject, "user", subject)

    with track:
        with st.form("add_task", clear_on_submit=True):
            c1, c2, c3, c4 = st.columns([3, 2, 2, 1])
            title = c1.text_input("Task")
            subj = c2.text_input("Subject", "General")
            due = c3.date_input("Due", date.today())
            mins = c4.number_input("Min", 5, 480, 45, step=5)
            if st.form_submit_button("Add task") and title.strip():
                db.add_task(title, subj, str(due), int(mins))
                st.rerun()

        tasks = db.list_tasks()
        if not tasks:
            st.info("No tasks yet. Add one above to start tracking your study time.")
            return

        done = sum(t["done"] for t in tasks)
        st.progress(done / len(tasks), text=f"{done} of {len(tasks)} tasks complete")

        for t in tasks:
            c1, c2, c3 = st.columns([6, 2, 1])
            checked = c1.checkbox(f"{t['title']} · {t['subject']}", value=bool(t["done"]),
                                  key=f"task_{t['id']}")
            if checked != bool(t["done"]):
                db.toggle_task(t["id"], checked)
                st.rerun()
            c2.markdown(f"<span class='aw-muted'>due {t['due']} · {t['minutes']} min</span>",
                        unsafe_allow_html=True)
            if c3.button("✕", key=f"del_{t['id']}"):
                db.delete_task(t["id"])
                st.rerun()

        df = pd.DataFrame(tasks)
        by_subject = df.groupby("subject")["minutes"].sum().reset_index()
        fig = px.bar(by_subject, x="subject", y="minutes", color="subject",
                     title="Planned minutes by subject")
        fig.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
                          plot_bgcolor="rgba(0,0,0,0)", height=320, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
