"""Code Assistant — fix, explain, optimise, generate and test code."""
import streamlit as st
from core import ai, db

LANGS = ["Python", "JavaScript", "TypeScript", "Java", "C++", "C#", "Go",
         "Rust", "SQL", "HTML/CSS", "Bash"]

TASKS = {
    "Fix Code":      "Find every bug, return the corrected code, then list what changed and why.",
    "Explain Code":  "Explain what the code does, line by line, for a junior developer.",
    "Optimize Code": "Improve performance and readability. Give before/after complexity.",
    "Generate Code": "Write clean, commented, production-ready code for the request below.",
    "Write Tests":   "Write thorough unit tests covering happy paths and edge cases.",
    "Convert":       "Translate the code to the target language, keeping behaviour identical.",
}

SAMPLE = 'def add(a, b):\n    c = a + b\n    print("Result: " + c)\n\nadd(2, 3)'


def render():
    st.subheader("⌨️ Code Assistant")
    st.caption("Generate code, fix errors, explain and optimize code.")

    c1, c2 = st.columns([3, 2])
    task = c1.radio("Task", list(TASKS), horizontal=True)
    lang = c2.selectbox("Language", LANGS)

    code = st.text_area("Your code or request", value=SAMPLE, height=220, key="code_input")

    if st.button("Run", type="primary"):
        if not code.strip():
            st.warning("Paste some code or describe what you want built.")
            return
        with st.spinner("Working through the code…"):
            out = ai.ask(
                f"Language: {lang}\n\n```\n{code}\n```",
                system=f"You are a senior {lang} engineer. {TASKS[task]} "
                       "Return the code in a fenced block first, then a short explanation.",
                temperature=0.3,
            )
        st.markdown(out)
        db.bump("codes_generated")
        db.log_message("Code Assistant", f"{task}: {code[:40]}", "user", code)
